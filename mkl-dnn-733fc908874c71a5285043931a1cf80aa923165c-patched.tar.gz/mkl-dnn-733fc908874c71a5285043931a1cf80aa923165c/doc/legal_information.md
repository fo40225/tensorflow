Legal Information {#legal_information}
======================================

No license (express or implied, by estoppel or otherwise) to any intellectual
property rights is granted by this document.

Intel disclaims all express and implied warranties, including without
limitation, the implied warranties of merchantability, fitness
for a particular purpose, and non-infringement, as well as any warranty
arising from course of performance, course of dealing, or usage in trade.

This document contains information on products, services and/or processes in
development. All information provided here is subject to change without
notice. Contact your Intel representative to obtain the latest forecast,
schedule, specifications and roadmaps.

The products and services described may contain defects or errors which may
cause deviations from published specifications. Current characterized errata 
are available on request.

Intel, the Intel logo, Intel Atom, Intel Core, Intel Inside, the Intel Inside
logo, Intel Nervana, Intel Xeon Phi, Pentium, VTune and Xeon are trademarks 
of Intel Corporation or its subsidiaries in the U.S. and/or other countries.

\* Other names and brands may be claimed as the property of others.

(C) 2016-2018, Intel Corporation.
